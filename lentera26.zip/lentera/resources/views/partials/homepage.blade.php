@extends('theme::template')
@section('layout')
<div class="container mx-auto lg:px-5 px-3 my-5 text-gray-600">
    <main class="w-full space-y-5">

        {{-- Slider --}}
        @if (!empty($slider_gambar['gambar']))
            @include('theme::partials.slider')
        @endif

        {{-- Widget Transparansi Anggaran --}}
        @include('theme::partials.apbdesa')

        {{-- Menu Pintasan Layanan --}}
        @include('theme::partials.menu_layanan')

        {{-- Aparatur Desa --}}
        @if (!empty($w_cos))
            @foreach ($w_cos as $widget)
                @if (($widget['isi'] ?? '') === 'aparatur_desa.blade.php' || ($widget['isi'] ?? '') === 'aparatur_desa.php')
                    @include('theme::widgets.aparatur_desa', ['judul_widget' => str_replace('Desa', ucwords(setting('sebutan_desa')), strip_tags($widget['judul']))])
                    @break
                @endif
            @endforeach
        @endif

        {{-- Statistik Nagari --}}
        @include('theme::widgets.statistik_nagari')

        {{-- Judul Artikel Terkini --}}
        <div class="flex justify-between items-center w-full">
            <h3 class="text-h4 text-primary-200">{{ $title }}</h3>
            <a href="{{ site_url('arsip') }}" class="text-sm hover:text-primary-100">Indeks <i class="fas fa-chevron-right ml-1"></i></a>
        </div>

        {{-- Artikel --}}
        @if (!empty($artikel))
            <div class="lt-article-grid">
                @foreach ($artikel as $post)
                    @include('theme::partials.artikel.list', ['post' => $post])
                @endforeach
            </div>
            <div class="pagination space-y-1 flex-wrap w-full">
                @include('theme::commons.paging', ['paging_page' => $paging_page ?? null])
            </div>
        @else
            @include('theme::partials.artikel.empty')
        @endif

        {{-- Widget Layanan Mandiri --}}
        @if (setting('layanan_mandiri') == 1)
            @include('theme::widgets.layanan_mandiri')
        @endif
    </main>
</div>
@endsection
