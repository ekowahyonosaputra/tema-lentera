<link rel="stylesheet" href="{{ theme_asset('css/style.min.css') }}&v2603">
<link rel="stylesheet" href="{{ theme_asset('css/custom.css') }}&v={{ @filemtime(FCPATH . 'desa/themes/lentera/assets/css/custom.css') }}">
