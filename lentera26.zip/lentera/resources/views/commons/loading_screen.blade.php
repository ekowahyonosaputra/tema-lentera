<div id="lt-loading-screen" style="position:fixed;inset:0;background:#fff;z-index:9999;display:flex;align-items:center;justify-content:center;">
    <img src="{{ gambar_desa($desa['logo'] ?? null) }}" alt="{{ $desa['nama_desa'] ?? '' }}" class="lt-loading-logo">
</div>
