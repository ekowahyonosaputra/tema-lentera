@php
    $bg_header   = $latar_website;
    $motto       = theme_config('motto_nagari', '');
    $event_judul = theme_config('event_judul', '');
    $event_tgl   = theme_config('event_tanggal', '');
    $logo_berputar = theme_config('logo_berputar', '0') === '1';
    $palet = ['hijau'=>'#0F6E56','biru'=>'#185fa5','merah'=>'#b91c1c','ungu'=>'#6d28d9','cokelat'=>'#854f0b'];
    $warna_hex = $palet[theme_config('warna_tema','hijau')] ?? '#0F6E56';
@endphp
<div class="container md:px-4 lg:px-5" x-data="{menuOpen: false}">
    <div class="lt-topbar text-left">
        <span id="lt-topbar-tanggal"></span>
        <span class="lt-topbar-sep">&bull;</span>
        <span id="lt-topbar-jam"></span>
    </div>
    <header style="background-image: url({{ $bg_header }});" class="bg-center bg-cover bg-no-repeat relative text-white lt-hero">
        <div class="absolute inset-0 lt-hero-overlay"></div>
        <button type="button" class="lg:hidden lt-hero-menu-btn" @click="menuOpen = !menuOpen" aria-label="Menu">
            <i class="fas fa-bars"></i>
        </button>
        @include('theme::commons.category_menu')
        <section class="relative z-10 px-4 lg:px-8 py-6 lt-hero-inner">
            <div class="lt-hero-identity">
                <a href="{{ site_url('/') }}" class="lt-hero-brand">
                    <img src="{{ gambar_desa($desa['logo']) }}" alt="Logo {{ $desa['nama_desa'] }}" class="{{ $logo_berputar ? 'lt-logo-spin' : '' }}">
                    <div>
                        <span class="lt-hero-title">{{ $desa['nama_desa'] }}</span>
                        <p class="lt-hero-sub">
                            {{ ucfirst(setting('sebutan_kecamatan_singkat')) }} {{ ucwords($desa['nama_kecamatan']) }},
                            {{ ucfirst(setting('sebutan_kabupaten_singkat')) }} {{ ucwords($desa['nama_kabupaten']) }}<br>
                            Provinsi {{ ucwords($desa['nama_propinsi']) }}
                        </p>
                        @if ($motto)
                            <p class="lt-hero-motto">Motto {{ ucfirst(setting('sebutan_desa')) }} : {{ strtoupper($motto) }}</p>
                        @endif
                    </div>
                </a>
            </div>
            @if ($event_judul && $event_tgl)
            <div class="lt-hero-countdown" data-target="{{ str_replace(' ', 'T', $event_tgl) }}">
                <p class="lt-hero-countdown-label">Perayaan</p>
                <p class="lt-hero-countdown-title">{{ $event_judul }}</p>
                <div class="lt-hero-countdown-box">
                    <div><strong data-unit="hari">0</strong><span>HARI</span></div>
                    <div><strong data-unit="jam">0</strong><span>JAM</span></div>
                    <div><strong data-unit="menit">0</strong><span>MENIT</span></div>
                    <div><strong data-unit="detik">0</strong><span>DETIK</span></div>
                </div>
            </div>
            @endif
        </section>
        @if ($teks_berjalan)
        <div class="lt-info-ticker">
            <span class="lt-info-ticker-tag"><i class="fas fa-bullhorn mr-2"></i>Info</span>
            <marquee onmouseover="this.stop();" onmouseout="this.start();" class="lt-info-ticker-text">
                @foreach ($teks_berjalan as $marquee)
                    <span class="px-3">{{ $marquee['teks'] }}
                        @if (trim($marquee['tautan']) && $marquee['judul_tautan'])
                            <a href="{{ $marquee['tautan'] }}">{{ $marquee['judul_tautan'] }}</a>
                        @endif
                    </span>
                @endforeach
            </marquee>
            <span class="lt-info-ticker-icons">
                @if (setting('layanan_mandiri') == 1)
                    <a href="{{ site_url('layanan-mandiri') }}" class="lt-info-icon-btn lt-info-icon-green" title="Layanan Mandiri"><i class="fas fa-user"></i></a>
                @endif
                <a href="{{ site_url('pengaduan') }}" class="lt-info-icon-btn lt-info-icon-red" title="Lapor Pengaduan"><i class="fas fa-list"></i></a>
                <a href="{{ site_url('siteman') }}" class="lt-info-icon-btn lt-info-icon-green" title="Login Admin"><i class="fas fa-lock"></i></a>
            </span>
        </div>
        @endif
    </header>
    @include('theme::commons.main_menu')
    <nav class="lg:hidden block" x-show="menuOpen" @click.outside="menuOpen=false">
        @include('theme::commons.mobile_menu')
    </nav>
</div>

<nav class="lt-bottomnav">
    <a href="{{ site_url('/') }}" class="lt-bottomnav-item"><i class="fas fa-home"></i><span>Beranda</span></a>
    <a href="{{ route('web.pemerintah.index') }}" class="lt-bottomnav-item"><i class="fas fa-users"></i><span>Perangkat</span></a>
    <a href="{{ route('web.lapak.index') }}" class="lt-bottomnav-item"><i class="fas fa-store"></i><span>Lapak</span></a>
    <a href="{{ route('web.pembangunan.index') }}" class="lt-bottomnav-item"><i class="fas fa-hard-hat"></i><span>Bangunan</span></a>
    <a href="{{ site_url('layanan-mandiri') }}" class="lt-bottomnav-item"><i class="fas fa-user-circle"></i><span>Mandiri</span></a>
</nav>
