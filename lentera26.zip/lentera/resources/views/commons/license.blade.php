@php
/**
 * Lentera License Check — Blade Version v4 for OpenSID v2603+
 */

const LNT_API_KEY2   = 'sk_live_e1573a1b1bb7c4d9f07a208cb5912f15';
const LNT_API_HOST2  = 'desakami.my.id';
const LNT_API_PATH2  = '/api/verify_lisensi.php';

if (!function_exists('lntr_seri_b')) {
    function lntr_seri_b() {
        $h = strtoupper(substr(md5('lentera_'.(request()->getHost()?:'localhost').'_'.get_app_key()),0,16));
        return implode('-',str_split($h,4));
    }
    function lntr_api_b(array $p): ?array {
        $host=LNT_API_HOST2; $qs=http_build_query($p); $log=DESAPATH.'.lntr.log';
        $urls=[["http://{$host}".LNT_API_PATH2."?{$qs}",true],["https://{$host}".LNT_API_PATH2."?{$qs}",true],["https://{$host}".LNT_API_PATH2."?{$qs}",false],["http://{$host}".LNT_API_PATH2."?{$qs}",false]];
        foreach($urls as $i=>[$url,$resolve]) {
            if(!function_exists('curl_init')) break;
            $opts=[CURLOPT_URL=>$url,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>20,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>0,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,CURLOPT_USERAGENT=>'LenteraTheme/2603',CURLOPT_HTTPHEADER=>['Accept: application/json']];
            if($resolve) $opts[CURLOPT_RESOLVE]=["{$host}:80:127.0.0.1","{$host}:443:127.0.0.1"];
            $ch=curl_init(); curl_setopt_array($ch,$opts); $r=curl_exec($ch); $ce=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
            @file_put_contents($log,date('[Y-m-d H:i:s] ')."#$i ".($r!==false&&empty($ce)&&$code>=200?'OK '.substr($r,0,100):"FAIL code={$code} err={$ce}")."
",FILE_APPEND);
            if($r!==false&&empty($ce)&&$code>=200&&$code<300){$d=json_decode($r,true);if(is_array($d))return lntr_norm_b($d);}
        }
        if(ini_get('allow_url_fopen')){
            $ctx=stream_context_create(['http'=>['timeout'=>15,'follow_location'=>1,'ignore_errors'=>true],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
            $r=@file_get_contents($urls[2][0],false,$ctx);
            if($r){$d=json_decode($r,true);if(is_array($d))return lntr_norm_b($d);}
        }
        return null;
    }
    function lntr_norm_b(array $d): array {
        if(isset($d['data'])&&is_array($d['data'])){$d=array_merge($d['data'],$d);unset($d['data']);}
        $s=strtolower((string)($d['status']??'')); $v=!empty($d['valid'])||in_array($s,['active','success','ok','valid','1'],true);
        return ['valid'=>(bool)$v,'reason'=>$d['reason']??($v?'active':'invalid'),'pesan'=>$d['message']??$d['pesan']??'',['nama_pemegang']=[$d['name']??$d['nama']??''],['expired_at']=[$d['expired_at']??null]];
    }
    function lntr_check_b(): array {
        $kode=trim(theme_config('kode_aktivasi','')); $domain=strtolower(request()->getHost()?:'localhost'); $cf=DESAPATH.'.lntr_cache'; $now=time();
        if(empty($kode)) return ['valid'=>false,'reason'=>'empty'];
        $cached=null;
        if(is_file($cf)){$c=json_decode(@file_get_contents($cf)?:'',true);if(is_array($c)&&($c['lisensi']??'')===$kode&&($c['domain']??'')===$domain)$cached=$c;}
        if($cached&&($now-($cached['ts']??0))<86400) return $cached;
        @unlink(DESAPATH.'.lntr.log');
        $result=lntr_api_b(['api_key'=>LNT_API_KEY2,'lisensi'=>$kode,'domain'=>$domain,'nomor_seri'=>lntr_seri_b()]);
        if($result===null){if($cached&&!empty($cached['valid'])&&($now-($cached['ts']??0))<604800)return array_merge($cached,['grace'=>true]);return['valid'=>false,'reason'=>'api_error','_log'=>@file_get_contents(DESAPATH.'.lntr.log')?:''];}
        @file_put_contents($cf,json_encode(array_merge($result,['ts'=>$now,'lisensi'=>$kode,'domain'=>$domain])));
        return $result;
    }
}

$_lntr = lntr_check_b();
$_lntr_valid = !empty($_lntr['valid']);
$_lntr_seri  = lntr_seri_b();
$_lntr_reason= $_lntr['reason'] ?? '';
$_lntr_domain= strtolower(request()->getHost() ?: 'localhost');
$_lntr_log   = $_lntr['_log'] ?? '';
@endphp

@if (!$_lntr_valid)
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Aktivasi Tema Lentera</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;background:#f0f4f8;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}.card{background:#fff;border-radius:18px;box-shadow:0 10px 40px rgba(0,0,0,.12);max-width:580px;width:100%;overflow:hidden}.top{background:linear-gradient(135deg,#0d3a2a,#0a5a3a);color:#fff;padding:28px 32px;text-align:center}.top h1{font-size:20px;font-weight:800;margin-bottom:4px}.top small{font-size:12px;opacity:.8}.body{padding:24px 28px;display:flex;flex-direction:column;gap:14px}.alert{padding:13px 16px;border-radius:10px;font-size:13px;line-height:1.6;display:flex;gap:10px}.warn{background:#fff8e1;border:1px solid #f5c842;color:#7a5a00}.err{background:#fff0f0;border:1px solid #f5a0a0;color:#7a0000}.seri{background:#f8f9fa;border:1px solid #dee2e6;border-radius:10px;padding:14px 16px}.seri label{display:block;font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#888;margin-bottom:4px}.seri-v{font-size:20px;font-weight:800;color:#0d3a2a;letter-spacing:.12em;font-family:monospace}.seri-h{font-size:11px;color:#777;margin-top:5px}.steps{font-size:13px;color:#374151;line-height:1.8}.steps ol{padding-left:18px}.btn{display:block;text-align:center;background:#25c26e;color:#fff;font-size:15px;font-weight:700;padding:13px;border-radius:10px;text-decoration:none}.btn:hover{background:#20b060;color:#fff;text-decoration:none}.sub{font-size:12px;color:#888;text-align:center}.sub a{color:#0d6e56}details{border:1px solid #dee2e6;border-radius:8px;padding:10px 12px;font-size:11px}summary{cursor:pointer;font-weight:700;color:#374151}table{width:100%;border-collapse:collapse;margin-top:8px}td{padding:3px 6px;border-bottom:1px solid #eee;font-size:11px}td:first-child{font-weight:600;width:120px}pre{font-size:10px;white-space:pre-wrap;word-break:break-all;margin-top:8px;padding:8px;background:#fff;border:1px solid #e0e0e0;border-radius:6px;max-height:150px;overflow-y:auto;color:#c0392b}.foot{text-align:center;font-size:10px;color:#ccc;padding:12px;border-top:1px solid #f0f0f0}</style>
</head>
<body>
<div class="card">
  <div class="top"><h1>🔑 Aktivasi Tema Lentera</h1><small>{{ $desa['nama_desa'] ?? '' }} · {{ $_lntr_domain }}</small></div>
  <div class="body">
    @if ($_lntr_reason === 'empty')
    <div class="alert warn">⚠️&nbsp;<span><strong>Kode Aktivasi belum diisi.</strong><br>Admin → Pengaturan → Tema → ⚙️ Lentera → <strong>Kode Aktivasi</strong></span></div>
    @elseif ($_lntr_reason === 'api_error')
    <div class="alert err">🌐&nbsp;<span><strong>Tidak dapat terhubung ke server verifikasi.</strong><br>Hubungi tim Lentera dengan informasi diagnostik di bawah.</span></div>
    @else
    <div class="alert err">❌&nbsp;<span><strong>Kode Aktivasi tidak valid.</strong> {{ $_lntr['pesan'] ?? '' }}</span></div>
    @endif
    <div class="seri"><label>Nomor Seri Instalasi</label><div class="seri-v">{{ $_lntr_seri }}</div><div class="seri-h">Gunakan saat membeli lisensi di desakami.my.id</div></div>
    <div class="steps"><strong>Cara Aktivasi:</strong><ol><li>Buka <strong>desakami.my.id</strong> dan beli lisensi Tema Lentera</li><li>Masukkan <strong>Nomor Seri</strong> di atas</li><li>Kode Aktivasi dikirim ke email Anda</li><li>Masukkan kode di Admin → Pengaturan → Tema → ⚙️ Lentera</li></ol></div>
    <a href="https://desakami.my.id" target="_blank" rel="noopener" class="btn">🛒 Beli / Aktifkan Lisensi di desakami.my.id</a>
    <p class="sub">Sudah punya kode? <a href="{{ site_url('siteman') }}">Login Admin</a></p>
    @if ($_lntr_reason === 'api_error')
    <details><summary>🔧 Informasi Diagnostik</summary>
    <table>
      <tr><td>Domain</td><td>{{ $_lntr_domain }}</td></tr>
      <tr><td>Nomor Seri</td><td>{{ $_lntr_seri }}</td></tr>
      <tr><td>Endpoint</td><td>https://{{ LNT_API_HOST2 }}{{ LNT_API_PATH2 }}</td></tr>
      <tr><td>cURL</td><td>{{ function_exists('curl_init') ? '✅ Ada' : '❌ Tidak ada' }}</td></tr>
      <tr><td>allow_url_fopen</td><td>{{ ini_get('allow_url_fopen') ? '✅' : '❌' }}</td></tr>
      <tr><td>PHP</td><td>{{ PHP_VERSION }}</td></tr>
    </table>
    @if ($_lntr_log)<pre>{{ substr($_lntr_log, -1000) }}</pre>@endif
    </details>
    @endif
  </div>
  <div class="foot">Tema Lentera v2603.1.0</div>
</div>
</body></html>
@php exit; @endphp
@endif
