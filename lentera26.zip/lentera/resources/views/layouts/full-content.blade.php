@extends('theme::template')
@section('layout')
<div class="container mx-auto lg:px-5 px-3 my-5 text-gray-600">
    <main class="w-full space-y-5">
        @yield('content')
    </main>
</div>
@endsection
