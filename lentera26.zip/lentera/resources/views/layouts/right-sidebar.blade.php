@extends('theme::template')
@section('layout')
<div class="container mx-auto lg:px-5 px-3 flex flex-col lg:flex-row my-5 gap-3 lg:gap-5 justify-between text-gray-600">
    <main class="lg:w-2/3 w-full space-y-5">
        @yield('content')
    </main>
    <aside class="lg:w-1/3 w-full">
        @yield('sidebar')
    </aside>
</div>
@endsection
