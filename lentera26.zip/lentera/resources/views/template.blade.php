@php
    $themeVersion   = 'v2603.1.0';
    $warna_tema     = theme_config('warna_tema', 'hijau');
    $logo_berputar  = theme_config('logo_berputar', '0') === '1';
    $tampilkan_wa   = theme_config('tampilkan_wa', '1') !== '0';
    $motto          = theme_config('motto_nagari', '');
    $event_judul    = theme_config('event_judul', '');
    $event_tgl      = theme_config('event_tanggal', '');
    $palet = ['hijau'=>'#0F6E56','biru'=>'#185fa5','merah'=>'#b91c1c','ungu'=>'#6d28d9','cokelat'=>'#854f0b'];
    $warna_hex = $palet[$warna_tema] ?? '#0F6E56';
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('theme::commons.meta')
    @include('theme::commons.source_css')
    @include('theme::commons.source_js')
    <title>@yield('title', $desa['nama_desa'] ?? '')</title>
    <style>
    :root { --primary-base-color: {{ $warna_hex }}; }
    .lt-main-nav,.lt-header-compact-bar{background:linear-gradient(to right,color-mix(in srgb,{{ $warna_hex }} 80%,#000),{{ $warna_hex }}) !important}
    .lt-hero-overlay{background:linear-gradient(120deg,rgba(0,0,0,0.55) 0%,color-mix(in srgb,{{ $warna_hex }} 60%,transparent) 60%,color-mix(in srgb,{{ $warna_hex }} 40%,transparent) 100%) !important;backdrop-filter:brightness(0.85)}
    .lt-footer-bg{background:linear-gradient(135deg,color-mix(in srgb,{{ $warna_hex }} 60%,#000),color-mix(in srgb,{{ $warna_hex }} 75%,#000)) !important}
    .lt-topbar{background:color-mix(in srgb,{{ $warna_hex }} 40%,#000) !important}
    .lt-anggaran-side{background:linear-gradient(135deg,color-mix(in srgb,{{ $warna_hex }} 90%,#000),color-mix(in srgb,{{ $warna_hex }} 70%,#007)) !important}
    </style>
    @stack('styles')
</head>
<body class="font-primary bg-gray-100">
    <div id="lt-loading-screen" style="position:fixed;inset:0;background:#fff;z-index:9999;display:flex;align-items:center;justify-content:center;">
        <img src="{{ gambar_desa($desa['logo'] ?? null) }}" alt="{{ $desa['nama_desa'] ?? '' }}" class="lt-loading-logo">
    </div>
    @include('theme::commons.license')
    @include('theme::commons.header')
    @yield('layout')
    @include('theme::commons.footer')
    @if($tampilkan_wa && !empty($desa['nomor_operator'] ?: $desa['telepon']))
        <a href="https://api.whatsapp.com/send?phone={{ format_telpon($desa['nomor_operator'] ?: $desa['telepon']) }}&text={{ urlencode('Halo, ingin info '.($desa['nama_desa'] ?? '')) }}" target="_blank" rel="noopener" class="lt-wa-btn"><i class="fab fa-whatsapp"></i></a>
    @endif
    <nav class="lt-bottomnav">
        <a href="{{ site_url('/') }}" class="lt-bottomnav-item"><i class="fas fa-home"></i><span>Beranda</span></a>
        <a href="{{ site_url('pemerintah') }}" class="lt-bottomnav-item"><i class="fas fa-users"></i><span>Perangkat</span></a>
        <a href="{{ site_url('lapak') }}" class="lt-bottomnav-item"><i class="fas fa-store"></i><span>Lapak</span></a>
        <a href="{{ site_url('pembangunan') }}" class="lt-bottomnav-item"><i class="fas fa-hard-hat"></i><span>Bangunan</span></a>
        <a href="{{ site_url('layanan-mandiri') }}" class="lt-bottomnav-item"><i class="fas fa-user-circle"></i><span>Mandiri</span></a>
    </nav>
    <script src="{{ theme_asset('js/script.min.js') }}&{{ $themeVersion }}"></script>
    <script>
    document.addEventListener('DOMContentLoaded',function(){
        var hari=['Minggu','Senin','Selasa','Rabu','Kamis',"Jum'at",'Sabtu'],bulan=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
        var elTgl=document.getElementById('lt-topbar-tanggal'),elJam=document.getElementById('lt-topbar-jam');
        function dua(n){return n<10?'0'+n:n;}
        function tick(){var now=new Date();if(elTgl)elTgl.textContent=hari[now.getDay()]+', '+now.getDate()+' '+bulan[now.getMonth()]+' '+now.getFullYear();if(elJam)elJam.textContent=dua(now.getHours())+':'+dua(now.getMinutes())+':'+dua(now.getSeconds())+' WIB';}
        tick();setInterval(tick,1000);
        window.addEventListener('load',function(){var ls=document.getElementById('lt-loading-screen');if(ls){ls.style.transition='opacity 0.4s ease';ls.style.opacity='0';setTimeout(function(){ls.style.display='none';},450);}});
    });
    </script>
    @stack('scripts')
</body>
</html>
