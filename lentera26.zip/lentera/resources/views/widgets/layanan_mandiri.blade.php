@php
    $nm_desa = \App\Models\Config::appKey()->first();
    $foto_kantor = $nm_desa->kantor_desa ?? null;
@endphp
<div class="lt-mandiri-wrap">
    <div class="lt-mandiri-left">
        <div class="lt-mandiri-title"><span>LAYANAN</span><span>MANDIRI</span></div>
        <p class="lt-mandiri-sub">{{ ucwords(setting('sebutan_desa') ?? 'Desa') }} Digital</p>
    </div>
    <div class="lt-mandiri-center">
        <img src="{{ gambar_desa($desa['logo'] ?? null) }}" alt="{{ $desa['nama_desa'] ?? '' }}" class="lt-mandiri-logo">
        <p class="lt-mandiri-desa">{{ $desa['nama_desa'] ?? '' }}</p>
        <a href="{{ site_url('layanan-mandiri/masuk') }}" class="lt-mandiri-btn"><i class="fas fa-lock mr-2"></i> Login Layanan Mandiri</a>
    </div>
    <div class="lt-mandiri-right">
        <div class="lt-mandiri-bg-foto" style="background-image:url('{{ gambar_desa($foto_kantor, true) }}')"></div>
        <div class="lt-mandiri-right-overlay"></div>
        <div class="lt-mandiri-bubble"><i class="fas fa-info-circle mr-1"></i> Hubungi Pemerintah {{ ucwords(setting('sebutan_desa') ?? 'Desa') }} untuk mendapatkan PIN</div>
    </div>
</div>
