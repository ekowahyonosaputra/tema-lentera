@php
try {
    $jml_laki      = (int) \App\Models\PendudukHidup::where('sex', 1)->count();
    $jml_perempuan = (int) \App\Models\PendudukHidup::where('sex', 2)->count();
    if ($jml_laki === 0 && $jml_perempuan === 0) {
        $jml_laki      = (int) DB::table('tweb_penduduk')->where('config_id', identitas('id'))->where('sex', 1)->count();
        $jml_perempuan = (int) DB::table('tweb_penduduk')->where('config_id', identitas('id'))->where('sex', 2)->count();
    }
} catch (\Throwable $e) {
    $jml_laki = $jml_perempuan = 0;
}
$jml_total = $jml_laki + $jml_perempuan;
$sebutan   = ucwords(setting('sebutan_desa') ?? 'Desa');
@endphp
<div class="lt-statnagari">
    <div class="lt-statnagari-title">
        <span class="lt-statnagari-title-1">Statistik</span>
        <span class="lt-statnagari-title-2">{{ $sebutan }}</span>
    </div>
    <div class="lt-statnagari-gender">
        <div class="lt-statnagari-gender-item">
            <div class="lt-statnagari-avatar lt-statnagari-avatar-l"><i class="fas fa-male"></i></div>
            <div><strong>{{ number_format($jml_laki,0,',','.') }}</strong><span>laki-laki</span></div>
        </div>
        <div class="lt-statnagari-gender-item">
            <div class="lt-statnagari-avatar lt-statnagari-avatar-p"><i class="fas fa-female"></i></div>
            <div><strong>{{ number_format($jml_perempuan,0,',','.') }}</strong><span>perempuan</span></div>
        </div>
        <div class="lt-statnagari-total">total <strong>{{ number_format($jml_total,0,',','.') }}</strong> penduduk</div>
    </div>
    <div class="lt-statnagari-kategori">
        <a href="{{ site_url('data-wilayah') }}" class="lt-statnagari-badge" style="--badge-color:#9b6bb3"><i class="fas fa-map-marker-alt"></i><span>Data Wilayah</span></a>
        <a href="{{ site_url('data-statistik/pendidikan-dalam-kk') }}" class="lt-statnagari-badge" style="--badge-color:#16a36a"><i class="fas fa-graduation-cap"></i><span>Data Pendidikan</span></a>
        <a href="{{ site_url('data-statistik/pekerjaan') }}" class="lt-statnagari-badge" style="--badge-color:#e08a2e"><i class="fas fa-tools"></i><span>Data Pekerjaan</span></a>
        <a href="{{ site_url('data-statistik/rentang-umur') }}" class="lt-statnagari-badge" style="--badge-color:#2f6f95"><i class="fas fa-users"></i><span>Data Usia</span></a>
    </div>
</div>
